<?php
echo "This content is generated with PHP at " . date("h:i:sa");
?>
