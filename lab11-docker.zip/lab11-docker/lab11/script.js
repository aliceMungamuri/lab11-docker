function showTime() {
    const now = new Date();
    document.getElementById("time").textContent = "Current time: " + now.toLocaleTimeString();
}
