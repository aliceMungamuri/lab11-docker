#include <stdio.h>
int main() {
    printf("Hello from Docker C!\n");
    return 0;
}
